import React from 'react';

export default function Host() {
  return (
    <div><h1>Hyra ut</h1></div>
  );
}
