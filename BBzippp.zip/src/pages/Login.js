import React from 'react';

export default function Login() {
  return (
    <div><h1>Logga in med BankID, Freja eID eller e-post</h1></div>
  );
}
