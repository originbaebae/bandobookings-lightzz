import React from 'react';

export default function Profile() {
  return (
    <div><h1>Din profil</h1></div>
  );
}
