import React from 'react';

export default function Booking() {
  return (
    <div><h1>Bokningssida</h1></div>
  );
}
